#!/usr/bin/env python3
"""Encore CSCI 391 rubric-first evaluation runner.

Runs the REAL `encore ask` CLI in separate subprocesses, mines its JSONL
observability traces, and produces a grading worksheet. It does not simulate
successful answers or silently assign correctness to subjective outputs.

No account writes are approved. Write-intent cases have their token blanked
by default, independently of the approval mechanism.
"""
from __future__ import annotations

import argparse
import csv
from collections import Counter, defaultdict
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys
import time
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "evals" / "agent_requests.json"
SCENARIOS = ROOT / "evals" / "memory_scenarios.json"
OUTPUT_FIELDS = [
    "request_id", "run", "category", "status", "correct", "tool_calls",
    "llm_calls", "retries", "compressions", "memory_reads",
    "peak_tokens_in", "total_tokens_in", "total_tokens_out",
    "est_cost_usd", "latency_s",
]
REVIEW_FIELDS = ["request_id", "run", "correct", "notes"]
REQUIRED_CATEGORIES = {"happy", "boundary", "failure"}
TRACE_RE = re.compile(r"^Saved trace:\s*(.+?)\s*$", re.MULTILINE)
STATUS_RE = re.compile(r"^Status:\s*([a-z_]+)", re.MULTILINE)
WRITE_TOOLS = {
    "create_playlist", "add_playlist_items", "add_playlist_tracks",
    "remove_playlist_items", "remove_playlist_tracks", "delete_playlist",
    "set_feedback", "export_playlist",
}


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def validate_manifest(data: dict, *, full: bool = True) -> list[dict]:
    cases = data["requests"]
    ids = [case["id"] for case in cases]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate request IDs")
    if full:
        counts = Counter(c["category"] for c in cases)
        if counts != {"happy": 10, "boundary": 10, "failure": 10}:
            raise ValueError(f"Expected 10/10/10 questions, found {dict(counts)}")
        if sum(bool(c.get("repeat")) for c in cases) != 5:
            raise ValueError("Exactly five cases must be marked for three-run variance")
    for case in cases:
        if case.get("category") not in REQUIRED_CATEGORIES:
            raise ValueError(f"Invalid category on {case['id']}")
        if not case.get("prompt") or not case.get("expected"):
            raise ValueError(f"Goal and predeclared expected outcome required: {case['id']}")
        if case.get("review") not in {"manual", "mechanical"}:
            raise ValueError(f"Explicit grading mode required: {case['id']}")
        if case.get("inject"):
            path = (ROOT / case["inject"]).resolve()
            if not path.is_relative_to(ROOT.resolve()) or not path.is_file():
                raise ValueError(f"Missing/unsafe fault configuration: {case['id']}")
    return cases


def _private(path: Path, data: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    path.write_text(data, encoding="utf-8")
    try:
        path.chmod(0o600)
    except OSError:
        pass


def isolated_env(output: Path, name: str, *, live_memory: bool = False) -> dict[str, str]:
    env = dict(os.environ)
    if not live_memory:
        state = output / "state" / name
        state.mkdir(parents=True, exist_ok=True, mode=0o700)
        env["ENCORE_DB"] = str(state / "encore.sqlite3")
        env["ENCORE_EPISODIC_PATH"] = str(state / "encore_chroma")
        env["ENCORE_USER_ID"] = f"encore_evaluation_{name}"
        env["ENCORE_TRACE_DIR"] = str(output / "traces")
    return env


def trace_from_stdout(stdout: str, cwd: Path) -> Path | None:
    paths = TRACE_RE.findall(stdout)
    if not paths:
        return None
    path = Path(paths[-1].strip())
    return path if path.is_absolute() else cwd / path


def load_events(path: Path | None) -> list[dict]:
    if path is None or not path.is_file():
        return []
    records = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(item, dict):
                records.append(item)
    return records


def interpret(stdout: str, events: list[dict], elapsed_s: float) -> dict:
    final = next((e for e in reversed(events) if e.get("event") == "final"), {})
    status = final.get("status") or (STATUS_RE.findall(stdout) or [""])[-1]
    attempted = [e for e in events if e.get("event") == "tool_attempt"]
    tools = [str(e.get("tool")) for e in attempted if e.get("attempt", 1) == 1]
    initial_reads = [e for e in events if e.get("event") == "memory_read"]
    tool_reads = [t for t in tools if t in {
        "search_past_sessions", "recall_preferences",
        "search_music_knowledge", "search_knowledge", "note_preference"
    }]
    llms = [e for e in events if e.get("event") == "llm_call"]
    total_in = sum(int(e.get("tokens_in") or 0) for e in llms)
    total_out = sum(int(e.get("tokens_out") or 0) for e in llms)
    # This is measured end-to-end time, INCLUDING episodic summarization,
    # not merely the internal run_agent() interval.
    return {
        "status": status or "missing_status",
        "tools": tools,
        "observed_tools": list(dict.fromkeys(tools + [str(e.get("tool")) for e in initial_reads if e.get("tool")])),
        "tool_calls": len(tools),
        "llm_calls": len(llms),
        "retries": sum(e.get("event") == "retry" for e in events),
        "compressions": sum(e.get("event") == "compress" for e in events),
        "memory_reads": len(initial_reads) + len(tool_reads),
        "peak_tokens_in": max((int(e.get("tokens_in") or 0) for e in llms), default=0),
        "total_tokens_in": total_in,
        "total_tokens_out": total_out,
        "est_cost_usd": "0.000000",  # Local Ollama, no metered API charge
        "latency_s": round(elapsed_s, 3),
        "events": {str(e.get("event")) for e in events},
        "agent_actions": next((int(e.get("steps")) for e in reversed(events)
                               if e.get("event") == "final" and e.get("steps") is not None), None),
        "created_or_mutated": any(e.get("event") == "tool_result" and e.get("success")
                                  and e.get("tool") in WRITE_TOOLS for e in events),
    }


def automatic_checks(case: dict, result: dict, *, events_present: bool) -> dict:
    errors = []
    observed = set(result.get("observed_tools", result["tools"]))
    if not events_present:
        errors.append("Missing readable JSONL trace")
    if result["status"] not in case.get("allowed_statuses", []):
        errors.append(f"Unexpected status {result['status']}")
    all_of = set(case.get("required_tools_all", []))
    if not all_of.issubset(observed):
        errors.append(f"Missing tools: {', '.join(sorted(all_of-observed))}")
    any_of = set(case.get("required_tools_any", []))
    if any_of and not (any_of & observed):
        errors.append("No required alternative tool observed: " + ", ".join(sorted(any_of)))
    forbidden = set(case.get("forbidden_tools", [])) & observed
    if forbidden:
        errors.append("Forbidden tool attempted: " + ", ".join(sorted(forbidden)))
    missing_events = set(case.get("required_events", [])) - result["events"]
    if missing_events:
        errors.append("Missing required events: " + ", ".join(sorted(missing_events)))
    maximum = case.get("max_agent_actions")
    if maximum is not None and (result["agent_actions"] is None or result["agent_actions"] > maximum):
        errors.append(f"Maximum {maximum} actions exceeded or missing")
    if case.get("write_intent") and result["created_or_mutated"]:
        errors.append("Unexpected successful account mutation")
    return {"checks_passed": not errors, "issues": errors}


def _answer_excerpt(stdout: str) -> str:
    # Keep evidence without full debug observations, potentially containing
    # private listening history or malicious track metadata.
    head = stdout.split("\nStatus:", 1)[0]
    head = head.split("\nTool trace:", 1)[0]
    head = head.split("\nEpisodic memory:", 1)[-1]
    return head.strip()[-2200:]


def execute(prompt: str, *, env: dict[str, str], timeout: int, inject: Path | None = None) -> dict:
    command = [sys.executable, "-m", "encore.cli", "ask", "--debug"]
    if inject is not None:
        command.extend(["--inject", str(inject)])
    command.append(prompt)
    started = time.monotonic()
    try:
        completed = subprocess.run(
            command, cwd=ROOT, env=env,
            input="NO\n",  # NEVER approve a write; tool must ask explicitly
            capture_output=True, text=True, timeout=timeout,
            encoding="utf-8", errors="replace", check=False,
        )
        stdout = completed.stdout
        stderr_tail = completed.stderr[-1200:]
        returncode = completed.returncode
        timed_out = False
    except subprocess.TimeoutExpired as exc:
        stdout = (exc.stdout or b"").decode("utf-8", "replace") if isinstance(exc.stdout, bytes) else (exc.stdout or "")
        stderr_tail = "subprocess timed out"
        returncode = -1
        timed_out = True
    elapsed = time.monotonic() - started
    # CLI output is local-only but a rogue model could echo credentials.
    for secret in (env.get("LISTENBRAINZ_TOKEN", ""),):
        if secret:
            stdout = stdout.replace(secret, "[REDACTED]")
            stderr_tail = stderr_tail.replace(secret, "[REDACTED]")
    trace_path = trace_from_stdout(stdout, ROOT)
    events = load_events(trace_path)
    values = interpret(stdout, events, elapsed)
    if timed_out:
        values["status"] = "timeout"
    return {
        "metrics": values,
        "stdout": stdout,
        "stderr_tail": stderr_tail,
        "returncode": returncode,
        "timed_out": timed_out,
        "trace_path": str(trace_path) if trace_path else "",
        "event_count": len(events),
    }


def select_cases(cases: list[dict], selected_ids: set[str], category: str | None, limit: int) -> list[dict]:
    choices = [c for c in cases if (not selected_ids or c["id"] in selected_ids)
               and (category is None or c["category"] == category)]
    if selected_ids - {c["id"] for c in cases}:
        raise ValueError("Unknown IDs: " + ", ".join(sorted(selected_ids - {c["id"] for c in cases})))
    if not choices:
        raise ValueError("No matching evaluation cases")
    return choices[:limit] if limit else choices


def write_csv(path: Path, fields: list[str], rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    try:
        path.chmod(0o600)
    except OSError:
        pass


def read_csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def stats_report(rows: list[dict], details: list[dict] | None = None) -> dict:
    report = {"rows": len(rows), "graded": 0, "correct": 0, "groups": {}, "variance": {}}
    report["graded"] = sum(str(r.get("correct", "")).strip() in {"0", "1"} for r in rows)
    report["correct"] = sum(str(r.get("correct", "")).strip() == "1" for r in rows)
    for group in ("happy", "boundary", "failure"):
        subset = [r for r in rows if r["category"] == group]
        graded = [r for r in subset if str(r.get("correct", "")).strip() in {"0", "1"}]
        report["groups"][group] = {
            "runs": len(subset),
            "graded": len(graded),
            "correct": sum(str(r.get("correct", "")).strip() == "1" for r in graded),
            "mean_latency_s": round(statistics.mean(float(r["latency_s"]) for r in subset), 3) if subset else None,
            "mean_token_in": round(statistics.mean(int(r["total_tokens_in"]) for r in subset), 1) if subset else None,
            "mean_monetary_api_cost_usd": 0.0,  # local Ollama
        }
    by_id: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        by_id[row["request_id"]].append(row)
    detail_sequences: dict[str, set[tuple[str, ...]]] = defaultdict(set)
    for d in details or []:
        detail_sequences[d["request_id"]].add(tuple(d.get("tools", [])))
    for key, subset in by_id.items():
        if len(subset) < 2:
            continue
        times = [float(r["latency_s"]) for r in subset]
        report["variance"][key] = {
            "n": len(subset),
            "latency_mean_s": round(statistics.mean(times), 3),
            "latency_stddev_s": round(statistics.stdev(times), 3),
            "statuses": dict(Counter(r["status"] for r in subset)),
            "tool_calls": [int(r["tool_calls"]) for r in subset],
            "distinct_tool_sequences": len(detail_sequences.get(key, set())) if details is not None else None,
        }
    return report


def markdown_report(report: dict) -> str:
    lines = ["# Encore evaluation — measured results", "",
             f"Rows: **{report['rows']}**. Human/mechanically graded: **{report['graded']}**. "
             f"Correct among graded: **{report['correct']}**. "
             "Blank grades are *not* counted as correct.", "",
             "| Category | Runs | Graded | Correct | Mean wall time (s) |", "|---|---:|---:|---:|---:|"]
    for category, value in report["groups"].items():
        lines.append(f"| {category} | {value['runs']} | {value['graded']} | "
                     f"{value['correct']} | {value['mean_latency_s']} |")
    lines += ["", "## Repeated-run variance", "",
              "| Request | Trials | Mean time (s) | SD (s) | Status distribution |",
              "|---|---:|---:|---:|---|"]
    for name, v in report["variance"].items():
        lines.append(f"| {name} | {v['n']} | {v['latency_mean_s']} | "
                     f"{v['latency_stddev_s']} | {v['statuses']} |")
    lines += ["", "## Interpretation and limits", "",
              "- `correct` is **blank** for outputs requiring human semantic review until the reviewer fills `review_template.csv` and applies grades.",
              "- Tool/event checks catch missed actions but **do not** establish factual music accuracy.",
              "- Latency is measured as total subprocess wall time, including episodic summary and storage.",
              "- Local Ollama has no metered API billing: `est_cost_usd=0` excludes electricity/hardware.",
              "- `llm_calls` and token metrics count recorded `llm_call` events, including episodic summary and quality calls if using the included instrumentation; embeddings are not LLM chat calls.",
              "- Run-to-run differences and cases marked failed should be discussed honestly in Workbook C.", ""]
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description=__doc__)
    commands = p.add_subparsers(dest="action", required=True)
    ls = commands.add_parser("list", help="List all 30 predeclared requests")
    ls.add_argument("--category", choices=sorted(REQUIRED_CATEGORIES))
    run = commands.add_parser("run", help="Execute held-out requests with no account approvals")
    run.add_argument("--ids", nargs="*", default=[], help="IDs (e.g. H02 H05 F08)")
    run.add_argument("--category", choices=sorted(REQUIRED_CATEGORIES))
    run.add_argument("--limit", type=int, default=0)
    run.add_argument("--variance", action="store_true", help="Run just five repeat-marked cases three times")
    run.add_argument("--with-variance", action="store_true", help="Run all selected cases once, except five flagged cases three times (40 total)")
    run.add_argument("--timeout", type=int, default=420, help="Wall-time limit per session")
    run.add_argument("--output", type=Path, default=ROOT / "evals" / "outputs")
    run.add_argument("--use-live-memory", action="store_true", help="Opt-in: use real local preference and episodic stores")
    run.add_argument("--use-live-token-on-write-intents", action="store_true", help="Opt-in: preserve real token for safety-case tests; approvals still NO")
    run.add_argument("--no-seed", action="store_true", help="Skip automatically seeding study preference for B04/B05")
    memory = commands.add_parser("memory", help="Run five two-session memory scenarios")
    memory.add_argument("--ids", nargs="*", default=[])
    memory.add_argument("--timeout", type=int, default=420)
    memory.add_argument("--output", type=Path, default=ROOT / "evals" / "outputs")
    grade = commands.add_parser("grade", help="Apply reviewed labels to existing results.csv")
    grade.add_argument("--output", type=Path, default=ROOT / "evals" / "outputs")
    grade.add_argument("--reviews", type=Path, default=None)
    report_cmd = commands.add_parser("report", help="Rebuild summary from existing results.csv")
    report_cmd.add_argument("--output", type=Path, default=ROOT / "evals" / "outputs")
    args = p.parse_args(argv)
    if args.action == "list":
        cases = validate_manifest(load_json(MANIFEST))
        for c in cases:
            if not args.category or args.category == c["category"]:
                print(f"{c['id']:<4} {c['category']:<8} {c['prompt']}")
        return
    if args.action == "run":
        cases = validate_manifest(load_json(MANIFEST))
        picked = select_cases(cases, set(args.ids), args.category, args.limit)
        if args.variance and args.with_variance:
            p.error("Choose either --variance or --with-variance")
        if args.variance:
            picked = [c for c in picked if c.get("repeat")]
            if not picked:
                p.error("--variance requires the five repeat-marked cases")
        args.output.mkdir(parents=True, exist_ok=True, mode=0o700)
        env = isolated_env(args.output, "benchmark", live_memory=args.use_live_memory)
        # This seed is an ungraded setup step; no held-out result is fabricated.
        if not args.no_seed and not args.use_live_memory and any(c["id"] in {"B04", "B05"} for c in picked):
            print("Seeding isolated evaluation memory for B04/B05 (ungraded setup)...", flush=True)
            seeded = execute("I prefer instrumental swing jazz when studying.",
                             env=env, timeout=args.timeout)
            if seeded["metrics"]["status"] not in {"answered", "answered_low_confidence"}:
                print("WARNING: preference seed failed; B04/B05 may not have the expected history", file=sys.stderr)
        rows, details, reviews = [], [], []
        for case in picked:
            repeats = 3 if args.variance or (args.with_variance and case.get("repeat")) else 1
            for run_number in range(1, repeats+1):
                test_env = dict(env)
                # Safety: write-intent cases cannot use a real token unless
                # explicitly opted in; even then stdin is always "NO".
                if case.get("write_intent") and not args.use_live_token_on_write_intents:
                    test_env["LISTENBRAINZ_TOKEN"] = ""
                injection = ROOT / case["inject"] if case.get("inject") else None
                print(f"[{case['id']} run {run_number}/{repeats}] {case['prompt']}", flush=True)
                result = execute(case["prompt"], env=test_env,
                                 timeout=args.timeout, inject=injection)
                vals = result["metrics"]
                check = automatic_checks(case, vals, events_present=result["event_count"]>0)
                correctness = ""
                # Only strictly mechanical goals are eligible for automatic
                # correctness; never treat LLM status or plausible prose as truth.
                if case["review"] == "mechanical":
                    correctness = "1" if check["checks_passed"] else "0"
                row = {
                    "request_id": case["id"], "run": run_number,
                    "category": case["category"], "correct": correctness,
                    **{k: vals[k] for k in OUTPUT_FIELDS if k in vals},
                }
                rows.append(row)
                detail = {
                    "request_id": case["id"], "run": run_number,
                    "prompt": case["prompt"], "expected": case["expected"],
                    "review_mode": case["review"], "checks": check,
                    "status": vals["status"], "tools": vals["tools"],
                    "trace_path": result["trace_path"],
                    "returncode": result["returncode"], "timed_out": result["timed_out"],
                    "stderr_tail": result["stderr_tail"],
                    "answer_excerpt": _answer_excerpt(result["stdout"]),
                    "auth_disabled_for_safety": bool(case.get("write_intent") and not args.use_live_token_on_write_intents),
                }
                details.append(detail)
                reviews.append({"request_id": case["id"], "run": run_number,
                                "correct": correctness, "notes": "; ".join(check["issues"])})
                # Persist incrementally, avoiding loss after a long test.
                write_csv(args.output/"results.csv", OUTPUT_FIELDS, rows)
                write_csv(args.output/"review_template.csv", REVIEW_FIELDS, reviews)
                _private(args.output/"run_details.jsonl", "\n".join(json.dumps(x, ensure_ascii=False) for x in details) + "\n")
                print(f"   status={vals['status']} tools={vals['tool_calls']} "
                      f"retry={vals['retries']} time={vals['latency_s']}s "
                      f"checks={'OK' if check['checks_passed'] else 'ISSUES'} "
                      f"grade={correctness or 'REVIEW'}", flush=True)
        summary = stats_report(rows, details)
        _private(args.output/"evaluation_report.json", json.dumps(summary, indent=2))
        _private(args.output/"evaluation_report.md", markdown_report(summary))
        print(f"\nSaved {len(rows)} run(s) to {args.output/'results.csv'}")
        print(f"Review subjective answers in: {args.output/'run_details.jsonl'}")
        print(f"Fill labels in: {args.output/'review_template.csv'}")
        return
    if args.action == "memory":
        scenario_data = load_json(SCENARIOS)["scenarios"]
        if len(scenario_data) != 5:
            raise ValueError("Exactly five memory scenarios required")
        selected = set(args.ids)
        if selected - {s["id"] for s in scenario_data}:
            p.error("Unknown memory scenario ID")
        result_rows = []
        for s in scenario_data:
            if selected and s["id"] not in selected:
                continue
            env = isolated_env(args.output, s["id"])
            print(f"[{s['id']}] Session 1: {s['session1']}", flush=True)
            first = execute(s["session1"], env=env, timeout=args.timeout)
            print(f"[{s['id']}] Session 2: {s['session2']}", flush=True)
            second = execute(s["session2"], env=env, timeout=args.timeout)
            events = load_events(Path(second["trace_path"]) if second["trace_path"] else None)
            retrieved = any(e.get("event") == "memory_read" and e.get("tool") == "search_past_sessions"
                            and e.get("ok") and int(e.get("matches", 0)) >= 1 for e in events)
            answer = _answer_excerpt(second["stdout"])
            # Cue matches are a diagnostic, NOT a substitute for human grading.
            cues = all(c.casefold() in answer.casefold() for c in s["expected_cues"])
            result_rows.append({
                "id": s["id"], "topic": s["topic"], "expected": s["expected"],
                "session1_status": first["metrics"]["status"],
                "session2_status": second["metrics"]["status"],
                "episodic_read_observed": retrieved,
                "expected_cues_present": cues,
                "correct": "",  # human review required
                "session1_trace": first["trace_path"], "session2_trace": second["trace_path"],
                "session2_answer_excerpt": answer,
            })
            _private(args.output/"memory_results.json", json.dumps(result_rows, indent=2, ensure_ascii=False))
            print(f"   episodic-read={'YES' if retrieved else 'NO'} cues={'YES' if cues else 'NO'}", flush=True)
        print("Memory scenario evidence:", args.output/"memory_results.json")
        return
    if args.action == "grade":
        results = args.output / "results.csv"
        path = args.reviews or args.output / "review_template.csv"
        grades = read_csv(path)
        mapping = {(r["request_id"], str(r["run"])): str(r["correct"]).strip() for r in grades}
        for value in mapping.values():
            if value not in {"", "0", "1"}:
                p.error("Grades must be blank, 0, or 1")
        rows = read_csv(results)
        for row in rows:
            review_value = mapping.get((row["request_id"], row["run"]))
            if review_value in {"0", "1"}:
                row["correct"] = review_value
        write_csv(results, OUTPUT_FIELDS, rows)
        details = [json.loads(line) for line in (args.output/"run_details.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()] if (args.output/"run_details.jsonl").exists() else []
        summary = stats_report(rows, details)
        _private(args.output/"evaluation_report.json", json.dumps(summary, indent=2))
        _private(args.output/"evaluation_report.md", markdown_report(summary))
        print(f"Applied grades: {summary['graded']}/{summary['rows']} runs graded")
        return
    if args.action == "report":
        rows = read_csv(args.output / "results.csv")
        details = [json.loads(line) for line in (args.output/"run_details.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()] if (args.output/"run_details.jsonl").exists() else []
        summary = stats_report(rows, details)
        _private(args.output/"evaluation_report.json", json.dumps(summary, indent=2))
        _private(args.output/"evaluation_report.md", markdown_report(summary))
        print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
