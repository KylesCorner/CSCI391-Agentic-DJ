# Encore evaluation — measured results

Rows: **3**. Human/mechanically graded: **0**. Correct among graded: **0**. Blank grades are *not* counted as correct.

| Category | Runs | Graded | Correct | Mean wall time (s) |
|---|---:|---:|---:|---:|
| happy | 2 | 0 | 0 | 40.239 |
| boundary | 0 | 0 | 0 | None |
| failure | 1 | 0 | 0 | 7.975 |

## Repeated-run variance

| Request | Trials | Mean time (s) | SD (s) | Status distribution |
|---|---:|---:|---:|---|

## Interpretation and limits

- `correct` is **blank** for outputs requiring human semantic review until the reviewer fills `review_template.csv` and applies grades.
- Tool/event checks catch missed actions but **do not** establish factual music accuracy.
- Latency is measured as total subprocess wall time, including episodic summary and storage.
- Local Ollama has no metered API billing: `est_cost_usd=0` excludes electricity/hardware.
- `llm_calls` and token metrics count recorded `llm_call` events, including episodic summary and quality calls if using the included instrumentation; embeddings are not LLM chat calls.
- Run-to-run differences and cases marked failed should be discussed honestly in Workbook C.
