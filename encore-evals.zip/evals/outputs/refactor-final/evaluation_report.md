# Encore evaluation — measured results

Rows: **40**. Human/mechanically graded: **1**. Correct among graded: **1**. Blank grades are *not* counted as correct.

| Category | Runs | Graded | Correct | Mean wall time (s) |
|---|---:|---:|---:|---:|
| happy | 14 | 0 | 0 | 58.311 |
| boundary | 12 | 0 | 0 | 56.848 |
| failure | 14 | 1 | 1 | 30.85 |

## Repeated-run variance

| Request | Trials | Mean time (s) | SD (s) | Status distribution |
|---|---:|---:|---:|---|
| H02 | 3 | 36.35 | 12.178 | {'answered': 3} |
| H05 | 3 | 113.893 | 42.523 | {'answered': 3} |
| B05 | 3 | 25.458 | 0.454 | {'answered_low_confidence': 1, 'stuck': 2} |
| F01 | 3 | 26.541 | 0.921 | {'answered': 3} |
| F08 | 3 | 8.825 | 0.283 | {'stuck': 3} |

## Interpretation and limits

- `correct` is **blank** for outputs requiring human semantic review until the reviewer fills `review_template.csv` and applies grades.
- Tool/event checks catch missed actions but **do not** establish factual music accuracy.
- Latency is measured as total subprocess wall time, including episodic summary and storage.
- Local Ollama has no metered API billing: `est_cost_usd=0` excludes electricity/hardware.
- `llm_calls` and token metrics count recorded `llm_call` events, including episodic summary and quality calls if using the included instrumentation; embeddings are not LLM chat calls.
- Run-to-run differences and cases marked failed should be discussed honestly in Workbook C.
