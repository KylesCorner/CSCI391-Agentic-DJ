# Encore evaluation — measured results

Rows: **40**. Human/mechanically graded: **1**. Correct among graded: **1**. Blank grades are *not* counted as correct.

| Category | Runs | Graded | Correct | Mean wall time (s) |
|---|---:|---:|---:|---:|
| happy | 14 | 0 | 0 | 48.317 |
| boundary | 12 | 0 | 0 | 48.43 |
| failure | 14 | 1 | 1 | 23.762 |

## Repeated-run variance

| Request | Trials | Mean time (s) | SD (s) | Status distribution |
|---|---:|---:|---:|---|
| H02 | 3 | 48.704 | 31.538 | {'budget_exceeded': 1, 'answered': 2} |
| H05 | 3 | 79.85 | 17.781 | {'stuck': 1, 'answered': 2} |
| B05 | 3 | 25.864 | 4.564 | {'stuck': 2, 'answered_low_confidence': 1} |
| F01 | 3 | 26.551 | 2.095 | {'answered': 3} |
| F08 | 3 | 8.085 | 0.08 | {'stuck': 3} |

## Interpretation and limits

- `correct` is **blank** for outputs requiring human semantic review until the reviewer fills `review_template.csv` and applies grades.
- Tool/event checks catch missed actions but **do not** establish factual music accuracy.
- Latency is measured as total subprocess wall time, including episodic summary and storage.
- Local Ollama has no metered API billing: `est_cost_usd=0` excludes electricity/hardware.
- `llm_calls` and token metrics count recorded `llm_call` events, including episodic summary and quality calls if using the included instrumentation; embeddings are not LLM chat calls.
- Run-to-run differences and cases marked failed should be discussed honestly in Workbook C.
